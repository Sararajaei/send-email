from setuptools import setup


setup(name='send_email',
      version='0.1',
      description='send_email by sara rajaei Demo Package',
      url='#',
      author='Sara Rajaei',
      author_email='sararj9894@gmail.com',
      license='MIT',
      packages=['send_email'],
      install_requires=[],
      zip_safe=False)
