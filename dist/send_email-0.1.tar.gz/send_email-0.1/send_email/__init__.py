from send_email.handler import send_email
__all__ = ['send_email']
